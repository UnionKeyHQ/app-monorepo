import { SolanaSignUnsafeMessage as HardwareSolSignUnsafeMessage } from '@onekeyfe/hd-transport';
import { UI_REQUEST } from '../../constants/ui-request';
import { validatePath } from '../helpers/pathUtils';
import { BaseMethod } from '../BaseMethod';
import { validateParams } from '../helpers/paramsValidator';
import { stripHexPrefix } from '../helpers/hexUtils';

export default class SolSignMessage extends BaseMethod<HardwareSolSignUnsafeMessage> {
  init() {
    this.checkDeviceId = true;
    this.notAllowDeviceMode = [...this.notAllowDeviceMode, UI_REQUEST.INITIALIZE];

    // check payload
    validateParams(this.payload, [
      { name: 'path', required: true },
      { name: 'messageHex', type: 'hexString', required: true },
    ]);

    const { path, messageHex } = this.payload;
    const addressN = validatePath(path, 3);

    // init params
    this.params = {
      address_n: addressN,
      message: stripHexPrefix(messageHex),
    };
  }

  getVersionRange() {
    return {
      pro: {
        min: '4.12.0',
      },
      touch: {
        min: '4.10.0',
      },
      model_classic1s: {
        min: '3.11.0',
      },
      model_mini: {
        min: '3.10.0',
      },
    };
  }

  async run() {
    const response = await this.device.commands.typedCall(
      'SolanaSignUnsafeMessage',
      'SolanaMessageSignature',
      {
        ...this.params,
      }
    );

    return Promise.resolve({
      signature: response.message.signature,
      pub: response.message.public_key,
    });
  }
}
